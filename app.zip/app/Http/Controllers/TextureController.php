<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Texture;

class TextureController extends Controller
{
    public function index(){

    }
    public function add(){


    }
    public function edit(){

    }
    public function update(){

    }
    public function remove(){

    }
}
